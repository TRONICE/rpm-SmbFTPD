/* Copyright 2003-2008 Wang, Chun-Pin All rights reserved. */
#include <stdio.h>
#include <stdlib.h>
#include <strings.h>

#include "smbftpd.h"
#include "ssl.h"

extern smbftpd_conf_t smbftpd_conf;
extern smbftpd_session_t smbftpd_session;

int cmd_auth(const char *method)
{
#ifdef	WITH_SSL

	if (!(smbftpd_conf.security_policy & SECURITY_POLICY_SECURE)) {
		reply(504, "AUTH: security mechanism '%s' not supported(%d).", method, __LINE__);
		return 0;
	}
	
	if (smbftpd_session.ssl_ctrl.ssl_active_flag) {
		reply_noformat(503, "We don't accept second AUTH command.");
		return -1;
	}

	if (strcasecmp(method, "SSL") == 0 || strcasecmp(method, "TLS-P") == 0) {
		
		reply(234, "AUTH %s command successful.", method);
	
		if (0 != ssl_init_session()) {
			reply(550, "TLS handshake failed.");
			dologout(1);
		}
		smbftpd_session.ssl_ctrl.ssl_encrypt_data = 1;

	} else if (strcasecmp(method, "TLS") == 0 || strcasecmp(method, "TLS-C") == 0) {
		
		reply(234, "AUTH %s command successful.", method);
	
		if (0 != ssl_init_session()) {
			reply_noformat(550, "TLS handshake failed.");
			dologout(1);
		}
	} else
#endif
		reply(504, "AUTH: security mechanism '%s' not supported(%d).", method);

	return 0;
}
