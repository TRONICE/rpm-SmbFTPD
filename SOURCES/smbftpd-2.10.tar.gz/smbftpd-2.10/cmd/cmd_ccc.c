#include <stdio.h>
#include "ssl.h"
#include "smbftpd.h"

extern smbftpd_conf_t smbftpd_conf;
extern smbftpd_session_t smbftpd_session;

void cmd_ccc(void)
{
	if (!smbftpd_session.ssl_ctrl.ssl_active_flag) {
		reply_noformat(533, "Control channel is not protected.");
		return;
	}
	if ( (smbftpd_session.guest == 0 && smbftpd_conf.normal_user_must_secure) ||
		!(smbftpd_conf.security_policy & SECURITY_POLICY_NOSECURE)) {
		reply_noformat(500, "CCC refused. TLS/SSL protection required.");
		return;
	}

	reply_noformat(200, "Clearing control channel protection.");

	ssl_end_session();
	smbftpd_session.ssl_ctrl.ssl_active_flag = 0;
}

