/* Copyright 2003-2008 Wang, Chun-Pin All rights reserved. */
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <dirent.h>
#include <unistd.h>
#include <sys/stat.h>
#include <stdarg.h>
#include <string.h>
#include <sys/param.h>
#include <sys/time.h>
#include <arpa/ftp.h>
#include <time.h>
#include <pwd.h>
#include <grp.h>
#include <syslog.h>
#include <errno.h>
#include <glob.h>
#include <stdlib.h>
#include <fnmatch.h>

#include "pathnames.h"
#include "smbftpd.h"
#include "cmd.h"
#include "ssl.h"

extern smbftpd_conf_t smbftpd_conf;
extern smbftpd_session_t smbftpd_session;

static int compose_response_LIST(const char *name, struct stat *pstat, char *buf, int buflen)
{
	struct tm tmfile;
	char perm[11], timestr[13];
	char link_target[MAXPATHLEN + 5], tmp[MAXPATHLEN + 1];
	char convert_buf[MAXPATHLEN+1];
	time_t t;
	
	bzero(buf, buflen);
	
	if (S_ISLNK(pstat->st_mode)) {
		int err;
		strcpy(perm, "lrwxrwxrwx");
		err = readlink(name, tmp, sizeof(tmp) - 1);
		if (err < 0) {
			syslog(LOG_ERR, "%s (%d) FTP readlink() error, error code:%d", 
				   __FILE__, __LINE__, errno);
			return -1;
		} else {
			tmp[err] = '\0';
		}

		snprintf(link_target, sizeof(link_target), " -> %s",
				 smbftpd_charset_fs2client(tmp, convert_buf, sizeof(convert_buf)));

	} else {
		strcpy(perm, "----------");
		if (S_ISDIR(pstat->st_mode))
			perm[0] = 'd';
		if (pstat->st_mode & S_IRUSR)
			perm[1] = 'r';
		if (pstat->st_mode & S_IWUSR)
			perm[2] = 'w';
		if (pstat->st_mode & S_IXUSR)
			perm[3] = 'x';
		if (pstat->st_mode & S_IRGRP)
			perm[4] = 'r';
		if (pstat->st_mode & S_IWGRP)
			perm[5] = 'w';
		if (pstat->st_mode & S_IXGRP)
			perm[6] = 'x';
		if (pstat->st_mode & S_IROTH)
			perm[7] = 'r';
		if (pstat->st_mode & S_IWOTH)
			perm[8] = 'w';
		if (pstat->st_mode & S_IXOTH)
			perm[9] = 'x';
		link_target[0] = '\0';		
	} 
	memcpy(&tmfile, localtime(&(pstat->st_mtime)), sizeof(struct tm));
	time(&t);
	if (tmfile.tm_year == localtime(&t)->tm_year){
		strncpy(timestr, ctime(&(pstat->st_mtime)) + 4, 12);
	} else {
		strftime(timestr, sizeof(timestr), "%b %d  %Y", &tmfile);
	}
	timestr[12]='\0';

	name = smbftpd_charset_fs2client(name, convert_buf, sizeof(convert_buf));
	snprintf(buf, buflen, "%s %3s %-8s %-8s %12llu %s %s%s\r\n", 
			 perm, "1", user_from_uid(pstat->st_uid, 0), group_from_gid(pstat->st_gid, 0),
			 (unsigned long long) pstat->st_size,
			 timestr, name, link_target);
	return 0;
}

static char *MLSx_type_get(const char *path, struct stat *pstat)
{
	static char buf[MAXPATHLEN+16];
	char link[MAXPATHLEN+1], convert_buf[MAXPATHLEN+1];
	
	bzero(buf, sizeof(buf));
	
	if (S_ISLNK(pstat->st_mode)) {
		bzero(link, sizeof(link));
		if (0 > readlink(path, link, sizeof(link))) {
			syslog(LOG_ERR, "%s (%d) readlink(%s) failed (%s)", __FILE__, __LINE__, path, strerror(errno));
			strcpy(buf, "OS.unix=symlink");
		} else {
			snprintf(buf, sizeof(buf), "Os.unix=slink:%s", smbftpd_charset_fs2client(link, convert_buf, sizeof(convert_buf)));
		}
	} else if (S_ISDIR(pstat->st_mode)) {
		strcpy(buf, "dir");
	} else {
		strcpy(buf, "file");
	}
	return buf;
}

static int compose_response_MLSx(const char *display_name, const char *path, struct stat *pstat, char *buf, int buflen, enum smbftpd_list_mode list_mode)
{
	struct tm tmfile;
	char convert_buf[MAXPATHLEN+1];
	char *ptr = buf;
	int bufstrlen = 0;

	bzero(buf, buflen);

	if (LIST_MODE_MLST == list_mode) {
		strcpy(buf, " ");
		bufstrlen = 1;
		ptr = buf+1;
	}

	memcpy(&tmfile, gmtime(&(pstat->st_mtime)), sizeof(struct tm));
	snprintf(ptr, buflen - bufstrlen, "modify=%04d%02d%02d%02d%02d%02d;", tmfile.tm_year+1900, 
		tmfile.tm_mon+1, tmfile.tm_mday, tmfile.tm_hour, tmfile.tm_min, tmfile.tm_sec);
	bufstrlen = strlen(buf);
	ptr = buf + bufstrlen;

	
	snprintf(ptr, buflen - bufstrlen, "type=%s;", MLSx_type_get(path, pstat));
	bufstrlen = strlen(buf);
	ptr = buf + bufstrlen;
	
	snprintf(ptr, buflen - bufstrlen, "unique=%lXU%lX;", 
			 (unsigned long) pstat->st_dev, (unsigned long) pstat->st_ino);
	bufstrlen = strlen(buf);
	ptr = buf + bufstrlen;

	snprintf(ptr, buflen - bufstrlen, "size=%llu;", (unsigned long long) pstat->st_size);
	bufstrlen = strlen(buf);
	ptr = buf + bufstrlen;
	
	snprintf(ptr, buflen - bufstrlen, "UNIX.mode=%04o;", pstat->st_mode & 0777);
	bufstrlen = strlen(buf);
	ptr = buf + bufstrlen;
	
	snprintf(ptr, buflen - bufstrlen, "UNIX.owner=%s;", user_from_uid(pstat->st_uid, 0));
	bufstrlen = strlen(buf);
	ptr = buf + bufstrlen;
	
	snprintf(ptr, buflen - bufstrlen, "UNIX.group=%s;", group_from_gid(pstat->st_gid, 0));
	bufstrlen = strlen(buf);
	ptr = buf + bufstrlen;

	snprintf(ptr, buflen - bufstrlen, " %s\r\n", smbftpd_charset_fs2client(display_name, convert_buf, sizeof(convert_buf)));

	return 0;
}

/**
 * stat a file or directory and send its information to client.
 * 
 * @param name    The path to list
 * @param pclient data stream
 * @param list_mode LIST_MODE_LIST, LIST_MODE_NLST, LIST_MODE_MLST, LIST_MODE_MLSD
 */
static void smbftpd_stat_filesystem(const char *name, const char *path, FILE * pclient, enum smbftpd_list_mode list_mode)
{
	struct stat st;
	char buf[MAXPATHLEN + 512];
	char convert_buf[MAXPATHLEN+1];
	const char *display_name;

	/* return on lstat failed. But for nlist, we don't use stat result.
	 * We can still continue;
	 */
	if ((list_mode != LIST_MODE_NLST) && (lstat(path, (struct stat *) &st) < 0)) {
		syslog(LOG_ERR, "%s (%d) Failed to lstat %s", __FILE__, __LINE__, path);
		return;
	}
	
	if (NULL != name) {
		display_name = name;
	} else {
		display_name = path;
	}

	switch (list_mode) {
		case LIST_MODE_NLST:
			name = smbftpd_charset_fs2client(display_name, convert_buf, sizeof(convert_buf));
			snprintf(buf, sizeof(buf), "%s\r\n", display_name);
			break;
		case LIST_MODE_LIST:
			if (S_ISLNK(st.st_mode) && (smbftpd_conf.show_symlinks == 0)) {
				return;
			}
			compose_response_LIST(display_name, &st, buf, sizeof(buf));
			
			break;
		case LIST_MODE_MLST:
		case LIST_MODE_MLSD:
			if (S_ISLNK(st.st_mode) && (smbftpd_conf.show_symlinks == 0)) {
				return;
			}
			compose_response_MLSx(display_name, path, &st, buf, sizeof(buf), list_mode);
			
			break;
		default:
			/* Never reached. */
			syslog(LOG_ERR, "Unknown list mode %d", list_mode);
			break;
	}

#ifdef WITH_SSL
	if (pclient == stdout && smbftpd_session.ssl_ctrl.ssl_active_flag) {
		ssl_write(ssl_con, buf, strlen(buf));
	} else if (smbftpd_session.ssl_ctrl.ssl_data_active_flag) {
		ssl_write(ssl_data_con, buf, strlen(buf));
	} else
#endif
	fprintf(pclient, "%s", buf);

	return;
}


/**
 * Check whether the pattern of path is allowed.
 * 
 * We don't support xxx/[?]/xxx, pattern matching is only supported 
 * for the last path component.
 * 
 * @param path   The path user inputed.
 * 
 * @return -1: path is not allowed
 *          0: ok
 */
static int path_sanity_check(const char *path)
{
	const char *pattern = "*?[";
	const char *ptr, *last_component, *pattern_pos;
	
	last_component = strrchr(path, '/');
	if (NULL == last_component) {
		// No need to check
		return 0;
	}
	
	if ((strstr(path, "/.")) && strchr(path, '*')) {
		return -1; /* DoS protection */
	}
		
	ptr = pattern;
	while (*ptr) {
		pattern_pos = strchr(path, *ptr);
		if (pattern_pos && pattern_pos < last_component) {
			// We don't support xxx/*/xxx, pattern matching is only supported within the last path component.
			return -1;
		}
		ptr++;
	}
	
	return 0;
}

/* Get the full path in MODE_NORMAL */
static const char *get_real_full_path(const char *path)
{
	static char full_path[MAXPATHLEN+1];
	char buf[MAXPATHLEN+1];
	char original_cwd[MAXPATHLEN+1];
	char cwd[MAXPATHLEN+1];
	const char *name;
	char *ptr;
	
	bzero(original_cwd, sizeof(original_cwd));
	getcwd(original_cwd, sizeof(original_cwd));
	
	snprintf(buf, sizeof(buf), "%s", path);
	
	name = path;
	ptr = strrchr(buf, '/');
	if (ptr) {
		*ptr = '\0';
		name = ptr+1;
		if (0 != chdir(buf)) {
			return path;
		}
	}
	if (0 == strcmp(name, ".") || 0 == strcmp(name, "..")) {
		chdir(name);
		getcwd(cwd, sizeof(cwd));
		snprintf(full_path, sizeof(full_path), "%s", cwd);
	} else {
		getcwd(cwd, sizeof(cwd));
		snprintf(full_path, sizeof(full_path), "%s/%s", cwd, name);
	}
	
	chdir(original_cwd);
	
	return full_path;
}
static char gcwd[MAXPATHLEN+1];
/**
 * Main routine of list command.
 * 
 * @param path      Path to list
 * @param pfclient  output data stream
 * @param list_mode LIST/NLIST/MLSD/MLST
 * @param recursive Recursive list or not
 * 
 * @return -1: Receive Abort command
 *         0: File list transfer complete
 */
int smbftpd_dir_list(const char *path, FILE * pfclient, enum smbftpd_list_mode list_mode, int recursive)
{
	struct stat st;
	char cwd[MAXPATHLEN+1], real_full_path[MAXPATHLEN+1], search_path[MAXPATHLEN+1];
	char buf[MAXPATHLEN+1], dir[MAXPATHLEN+1], *ptr;
	const char *pattern = NULL;
	int i, flags = FLAG_NO_FOLLOW_LAST_LINK, need_full_path = 0, need_concate_path = 0;
	glob_t gl;

	if (0 != path_sanity_check(path)) {
		// return empty list by return directly
		if (smbftpd_conf.debug_mode) {
			syslog(LOG_DEBUG, "%s : path_sanity_check failed", path);
		}
		return 0;
	}
	
	if (list_mode == LIST_MODE_MLST) {
		need_full_path = 1;
	}


	/* If need pattern match, get the real path of parent directory. (and it won't follow link)
	 * Otherwise, get the real path of full path.
	 */
	snprintf(search_path, sizeof(search_path), "%s", path);
	if (strchr(path, '*') || strchr(path, '?') || strchr(path, '[')) {
		ptr = strrchr(search_path, '/');
		if (NULL != ptr) {
			// Since we have done the sanity check, pattern must behind the last  '/'
			if (ptr == search_path) {
				// "/hom*", the search_path should be "/"
				ptr++;
			}
			*ptr = '\0';

			flags = 0;
			need_concate_path = 1;
			pattern = strrchr(path, '/') + 1;
		} else {
			strcpy(search_path, ".");
			pattern = path;
		}
	} else {
		if (search_path[strlen(search_path) - 1] == '/') {
			/* When there is a '/' in the end, means it will follow the link. Need to check
			 * the permission of the link, too.
			 */
			flags = 0;
		}
	}

	ptr = smbftpd_get_realpath(smbftpd_session.valid_shares, search_path, flags);
	if (NULL == ptr) {
		goto ErrorOut;
	}
	if (*ptr != '/') {
		/* smbftpd_get_realpath() would return full real path only in MODE_SMB
		 * for MODE_NORMAL, need to get the full path by the following function.
		 */
		snprintf(real_full_path, sizeof(real_full_path), "%s", get_real_full_path(search_path));
	} else {
		snprintf(real_full_path, sizeof(real_full_path), "%s", ptr);
	}
	

	/* Handle root directory and list shares in SMB MODE */
	if ((smbftpd_session.mode == MODE_SMB) && strcmp(real_full_path, PATH_SMB_FTPD_ROOT) == 0) {
		smbftpd_valid_share_t *p = smbftpd_session.valid_shares;
		
		// MLST, just list the directory attribute

		if (list_mode == LIST_MODE_MLST) {
			if (pattern != NULL) {
				goto ErrorOut;
			}
			smbftpd_stat_filesystem("/", PATH_SMB_FTPD_ROOT, pfclient, list_mode);
			return 0;
 		}

		if (list_mode == LIST_MODE_NLST && (strchr(path, '/') || strcmp(path, "..") == 0)) {
			need_concate_path = 1;
		}
		if (need_concate_path) {
			snprintf(dir, sizeof(dir), "%s", path);
			if (pattern != NULL) {
				ptr = strrchr(dir, '/');
				if (ptr) {
					*ptr = '\0';
				} else {
					syslog(LOG_ERR, "%s (%d) %s has no /. Should not happen", __FILE__, __LINE__, path);
				}
			} else {
				ptr = dir + strlen(dir) - 1; // strlen(dir) won't be 0?!
				if (*ptr == '/') {
					*ptr = '\0';
				}
			}

		}		

		while (p) {
			// List all readable shares
			if (p->browseable) {
				if (pattern && (0 != fnmatch(pattern, p->share, FNM_NOESCAPE))) {
					p = p->next;
					continue;
				}
				if (need_full_path) {
					snprintf(buf, sizeof(buf), "/%s", p->share);
				} else if (need_concate_path) {
					snprintf(buf, sizeof(buf), "%s/%s", dir, p->share);
				} else {
					snprintf(buf, sizeof(buf), "%s", p->share);
				}
				START_UNSAFE;
				smbftpd_stat_filesystem(buf, p->path, pfclient, list_mode);
				END_UNSAFE;
				if (sigurg_received()) {
					if (check_oob()) {
						return -1;
					}
				}
			}
			p = p->next;
		}
		return 0;
	}
	

	/* Check whether the folder can be listed. */
	if (smbftpd_session.mode == MODE_SMB) {
		const smbftpd_valid_share_t *share;
		share = smbftpd_get_share_by_path(smbftpd_session.valid_shares, real_full_path);
		if (!share || share->disable_ls) {
			return 0;
		}
	}

	bzero(cwd, sizeof(cwd));
	getcwd(cwd, sizeof(cwd) - 1);

	if (lstat(real_full_path, (struct stat *) &st) < 0) {
		goto ErrorOut;
	}

	if (!S_ISDIR(st.st_mode) || (list_mode == LIST_MODE_MLST)) {
		// Just list the attribute of a file/dir
		
		if (pattern) {
			goto ErrorOut;
		}

		if (need_full_path) {
			snprintf(buf, sizeof(buf), "%s", real_full_path);
			smbfptd_replace_share_path(smbftpd_session.valid_shares, buf, sizeof(buf));
			smbftpd_stat_filesystem(buf, real_full_path, pfclient, list_mode);
		} else {
			smbftpd_stat_filesystem(path, real_full_path, pfclient, list_mode);
		}

		return 0;
	}

	
	// Handle directory here
	if (0 != chdir(real_full_path)) {
		goto ErrorOut;
	}
	if (pattern) {
		glob(pattern, 0, NULL, &gl);
	} else {
		if ((list_mode == LIST_MODE_NLST) && (strcmp(path, ".") != 0)) {
			need_concate_path = 1;
		}
		// Also list file begin with dot
		if (smbftpd_conf.show_dot_files) {
			glob(".*", 0, NULL, &gl);
			glob("*", GLOB_APPEND, NULL, &gl);
		} else {
			glob("*", 0, NULL, &gl);
		}
	}


	// The recursive stuff is for ffftp, it recursive lists all files
	// before deletes them.
	if (recursive == 1) {
		snprintf(gcwd, sizeof(gcwd), "%s", cwd);
	} else if (recursive > 1) {
		char convert_buf[PATH_MAX+1];

		if (strncmp(gcwd, real_full_path, strlen(gcwd)) == 0) {
			ptr = real_full_path + strlen(gcwd) + 1;
		} else {
			ptr = real_full_path;
		}

		snprintf(buf, sizeof(buf), "\r\n./%s:\r\n",
				 smbftpd_charset_fs2client(ptr, convert_buf, sizeof(convert_buf)));

		START_UNSAFE;
#ifdef WITH_SSL
		if (pfclient == stdout && smbftpd_session.ssl_ctrl.ssl_active_flag) {
			ssl_write(ssl_con, buf, strlen(buf));
		} else if (smbftpd_session.ssl_ctrl.ssl_data_active_flag) {
			ssl_write(ssl_data_con, buf, strlen(buf));
		} else 
#endif
			fprintf(pfclient, "%s", buf);
		END_UNSAFE;
		if (sigurg_received()) {
			if (check_oob()) {
				chdir(cwd);
				globfree(&gl);
				return -1;
			}
		}
	}

	if (need_full_path) {
		snprintf(dir, sizeof(dir), "%s", real_full_path);
		smbfptd_replace_share_path(smbftpd_session.valid_shares, dir, sizeof(dir));
	} else if (need_concate_path) {

		snprintf(dir, sizeof(dir), "%s", path);
		if (pattern != NULL) {
			ptr = strrchr(dir, '/');
			if (ptr) {
				*ptr = '\0';
			} else {
				syslog(LOG_ERR, "%s (%d) %s has no /. Should not happen", __FILE__, __LINE__, path);
			}
		} else {
			ptr = dir + strlen(dir) - 1; // strlen(dir) won't be 0?!
			if (*ptr == '/') {
				*ptr = '\0';
			}
		}
	}
	for (i = 0; i < gl.gl_pathc; i++){
		if ((strcmp(gl.gl_pathv[i],".")==0) ||
			(strcmp(gl.gl_pathv[i],"..")==0)) {
			continue;
		}
		START_UNSAFE;
		if (need_full_path || need_concate_path) {
			snprintf(buf, sizeof(buf), "%s/%s", dir, gl.gl_pathv[i]);
			smbftpd_stat_filesystem(buf, gl.gl_pathv[i], pfclient, list_mode);
		} else {
			smbftpd_stat_filesystem(NULL, gl.gl_pathv[i], pfclient, list_mode);
		}
		END_UNSAFE;
		if (sigurg_received()) {
			if (check_oob()) {
				chdir(cwd);
				globfree(&gl);
				return -1;
			}
		}
	}

	if (recursive) {
		int err = 0;
		for (i = 0; i < gl.gl_pathc; i++) {
			if ((strcmp(gl.gl_pathv[i],".")==0) ||
				(strcmp(gl.gl_pathv[i],"..")==0)) {
				continue;
			}
			bzero(&st, sizeof(st));
			lstat(gl.gl_pathv[i], (struct stat *) &st);
			if (S_ISDIR(st.st_mode)) {
				err = smbftpd_dir_list(gl.gl_pathv[i], pfclient, list_mode, recursive+1);
				if (err != 0) {
					chdir(cwd);
					globfree(&gl);
					return err;
				}
			}
		}
	}
	chdir(cwd);
	globfree(&gl);

	return 0;

ErrorOut:
	{
	char convert_buf[MAXPATHLEN + 1];
	path = smbftpd_charset_fs2client(path, convert_buf, sizeof(convert_buf));

	#ifdef WITH_SSL
	if (pfclient == stdout && smbftpd_session.ssl_ctrl.ssl_active_flag) {
		snprintf(buf, sizeof(buf), "550 %s: No such file or directory.\r\n", path);
		ssl_write(ssl_con, buf, strlen(buf));
	} else if (smbftpd_session.ssl_ctrl.ssl_data_active_flag) {
		snprintf(buf, sizeof(buf), "550: %s: No such file or directory.\r\n", path);
		ssl_write(ssl_data_con, buf, strlen(buf));
	} else 
	#endif
	fprintf(pfclient,"550: %s: No such file or directory.\r\n", path);
	}
	return 0;
}

/**
 * list files in dirname.
 * When verbose == 1, means "ls -l".
 * When verbose == 0, means "ls"
 * 
 * @param dirname Directory or filename to list
 * @param list_mode LIST_MODE_LIST, LIST_MODE_NLST
 */
void cmd_list(const char *dirname, enum smbftpd_list_mode list_mode)
{
	FILE *datastream = NULL;
	int recursive = 0;
	int error;

	if (dirname[0] != '\0') {
		/* skip arguments */
		if (dirname[0] == '-') {
			while ((dirname[0] != ' ') && (dirname[0] != '\0')) {
				// For ffftp. It send "nlist -l" to do file list.
				if ( (list_mode == LIST_MODE_NLST) && (dirname[0] == 'l') ) {
					list_mode = LIST_MODE_LIST;
				}
				// This is for ffftp, too. When it delete files, it use
				// nlist -alLR to recursive enlist all files recursive.
				// and then delete them.
				if ( (recursive == 0) && (dirname[0] == 'R')) {
					recursive = 1;
				}
				dirname++;
			}
			if (dirname[0] != '\0')
				dirname++;
		}
	}

	datastream = dataconn("file list", -1, "w");
	if (datastream == NULL) {
		reply(550, "Data connection: %s", strerror(errno));
		dataconnclose(datastream);
		return;
	}

	STARTXFER;

	if (dirname[0] == '\0') {
		error = smbftpd_dir_list(".", datastream, list_mode, recursive);
	} else {
		error = smbftpd_dir_list(dirname, datastream, list_mode, recursive);
	}

	ENDXFER;

	if (error == 0) {
		reply_noformat(226, "Transfer complete.");
	}
	
	dataconnclose(datastream);
}


