/* Copyright 2003-2015 Wang, Chun-Pin All rights reserved. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <errno.h>
#include <sys/stat.h>

#include "smbftpd.h"
#include "cmd.h"
#include "cmd_int.h"

extern smbftpd_session_t smbftpd_session;

void cmd_mlsd(const char *dirname)
{
	FILE *datastream = NULL;
	struct stat st;
	const char *realpath;
	int error;

	realpath = smbftpd_get_realpath(smbftpd_session.valid_shares, dirname, 0);

	if (NULL == realpath || 0 != lstat(realpath, &st)) {
		reply_fs2client(550, "%s can't be listed", dirname);
		return;
	}
	if (!S_ISDIR(st.st_mode)) {
		reply_fs2client(550, "%s is not a directory", dirname);
		return;
	}

	datastream = dataconn("file list", -1, "w");
	if (datastream == NULL) {
		reply(550, "Data connection: %s", strerror(errno));
		dataconnclose(datastream);
		return;
	}

	STARTXFER;

	if (dirname[0] == '\0') {
		error = smbftpd_dir_list(".", datastream, LIST_MODE_MLSD, 0);
	} else {
		error = smbftpd_dir_list(dirname, datastream, LIST_MODE_MLSD, 0);
	}

	ENDXFER;

	if (error == 0) {
		reply_noformat(226, "Transfer complete.");
	}
	
	dataconnclose(datastream);
	return;
}
