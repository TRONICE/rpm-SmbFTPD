/* Copyright 2003-2015 Wang, Chun-Pin All rights reserved. */
#include <stdio.h>
#include <sys/param.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <syslog.h>
#include <errno.h>
	 
#include "pathnames.h"
#include "smbftpd.h"
#include "cmd.h"
#include "cmd_int.h"
#include "ssl.h"

extern smbftpd_session_t smbftpd_session;

void cmd_mlst(const char *path)
{
	struct stat st;
	char *realpath;
	
	realpath = smbftpd_get_realpath(smbftpd_session.valid_shares, path, FLAG_NO_FOLLOW_LAST_LINK);
	if (NULL == realpath || 0 != lstat(realpath, &st)) {
		reply_fs2client(550, "%s can't be listed", path);
		return;
	}

	reply_fs2client(LONG_REPLY(250), "Start of list for %s", path);
	smbftpd_dir_list(path, stdout, LIST_MODE_MLST, 0);
	reply_noformat(250, "End of list");

	return;
}
