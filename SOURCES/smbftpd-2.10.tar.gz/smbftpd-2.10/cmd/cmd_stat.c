/* Copyright 2003-2008 Wang, Chun-Pin All rights reserved. */
#include <stdio.h>
#include <arpa/ftp.h>

#include "smbftpd.h"
#include "ssl.h"

extern smbftpd_conf_t smbftpd_conf;
extern smbftpd_session_t smbftpd_session;

void cmd_stat()
{
	reply(LONG_REPLY(211), "%s FTP server status:", smbftpd_conf.server_name);
	smbftpd_socket_printf("   Connected from %s\r\n", smbftpd_session.remotehost);
	smbftpd_socket_printf("   Login in as %s\r\n", smbftpd_session.username);
	if (smbftpd_session.ssl_ctrl.ssl_active_flag) {
		smbftpd_socket_printf("   Control connection is encrypted.\r\n");
	} else {
		smbftpd_socket_printf("   Control connection is plain text.\r\n");
	}
	smbftpd_socket_printf("   Type: %s\r\n", (smbftpd_session.transfer_type == TYPE_A)?"ASCII":"BINARY");
	if (smbftpd_session.max_upload_rate > 0) {
		smbftpd_socket_printf("   Max upload rate: %lu KB/s\r\n", smbftpd_session.max_upload_rate/1024);
	} else {
		smbftpd_socket_printf("   Max upload rate: unlimited\r\n");
	}
	if (smbftpd_session.max_download_rate > 0) {
		smbftpd_socket_printf("   Max download rate: %lu KB/s\r\n", smbftpd_session.max_download_rate/1024);
	} else {
		smbftpd_socket_printf("   Max download rate: unlimited\r\n");
	}
	smbftpd_socket_printf("   Total bytes uploaded: %llu bytes\r\n", smbftpd_session.byte_uploaded);
	smbftpd_socket_printf("   Total bytes downlaoded: %llu bytes\r\n", smbftpd_session.byte_downloaded);
	
	reply_noformat(211, "End of status.");
}
