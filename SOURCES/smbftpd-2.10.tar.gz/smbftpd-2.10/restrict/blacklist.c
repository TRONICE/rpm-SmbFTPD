#include "smbftpd.h"

#ifdef HAVE_BLACKLIST
#include <syslog.h>
#include <blacklist.h>

extern smbftpd_conf_t smbftpd_conf;

static struct blacklist *blstate;

void smbftpd_blacklist_init(void)
{
	if (smbftpd_conf.use_blacklist) {
		blstate = blacklist_open();
	}
}

void smbftpd_blacklist_notify(int auth_failed)
{
	int action = BLACKLIST_AUTH_OK;
	
	if (!blstate) {
		return;
	}
	
	if (auth_failed) {
		action = BLACKLIST_AUTH_FAIL;
	}
	(void)blacklist_r(blstate, action, 0, "smbftpd");
}
#else

void smbftpd_blacklist_init(void) {}
void smbftpd_blacklist_notify(int auth_failed) {}
#endif
