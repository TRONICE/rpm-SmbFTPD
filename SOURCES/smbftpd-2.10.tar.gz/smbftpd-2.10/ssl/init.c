/* Copyright 2003-2008 Wang, Chun-Pin All rights reserved. */
#include <stdio.h>
#include <syslog.h>
#include <string.h>

#include "ssl.h"
#include "smbftpd.h"

extern smbftpd_conf_t smbftpd_conf;
extern smbftpd_session_t smbftpd_session;

#ifdef WITH_SSL
SSL_CTX	*ssl_ctx = NULL;

static RSA *ssl_tmp_rsa512 = NULL;
static RSA *ssl_tmp_rsa1024 = NULL;
static RSA *ssl_tmp_rsa_cb(SSL *ssl, int is_export, int keylen)
{
	BIGNUM *e = NULL;
	RSA *ssl_tmp_rsa = NULL;

	switch (keylen) {
	case 512:
		if (ssl_tmp_rsa512) return ssl_tmp_rsa512;
		break;
	case 1024:
		if (ssl_tmp_rsa1024) return ssl_tmp_rsa1024;
		break;
	default:
		syslog(LOG_ERR, "Unexpected temp RSA key length: %d", keylen);
		return NULL;
	}

	if (smbftpd_conf.debug_mode) {
		syslog(LOG_DEBUG, "Generating temp (%d bit) RSA key", keylen);
	}

#if OPENSSL_VERSION_NUMBER > 0x000908000L
	e = BN_new();
	if (e == NULL) {
		return NULL;
	}

	if (BN_set_word(e, RSA_F4) != 1) {
		BN_free(e);
		return NULL;
	}

	ssl_tmp_rsa = RSA_new();
	if (RSA_generate_key_ex(ssl_tmp_rsa, keylen, e, NULL) != 1) {
		RSA_free(ssl_tmp_rsa);
		ssl_tmp_rsa = NULL;
		BN_free(e);
		return NULL;
	}

#else
	/* RSA_generate_key() is deprecated. */
	ssl_tmp_rsa = RSA_generate_key(keylen, RSA_F4, NULL, NULL);
#endif

	if (e != NULL) {
		BN_free(e);
	}

	if (keylen == 512) {
		ssl_tmp_rsa512 = ssl_tmp_rsa;
	} else {
		ssl_tmp_rsa1024 = ssl_tmp_rsa;
	}
	return ssl_tmp_rsa;
}

static DH *make_dh(BIGNUM *(*prime)(BIGNUM *), const char *gen)
{
	DH *dh = DH_new();
	BIGNUM *p, *g;

	if (!dh) {
		return NULL;
	}
	p = prime(NULL);
	g = BN_new();
	if (g != NULL) {
		BN_set_word(g, 2);
	}
	if (!p || !g || !DH_set0_pqg(dh, p, NULL, g)) {
		DH_free(dh);
		BN_free(p);
		BN_free(g);
		return NULL;
	}
	return dh;
}

/* Storage and initialization for DH parameters. */
static struct dhparam {
	BIGNUM *(*const prime)(BIGNUM *); /* function to generate... */
	DH *dh;                           /* catched DH key */
	const unsigned int min;           /* ...of length >= this. */
} dhparams[] = {
	{ get_rfc3526_prime_8192, NULL, 6145 },
	{ get_rfc3526_prime_6144, NULL, 4097 },
	{ get_rfc3526_prime_4096, NULL, 3073 },
	{ get_rfc3526_prime_3072, NULL, 2049 },
	{ get_rfc3526_prime_2048, NULL, 1025 },
	{ get_rfc2409_prime_1024, NULL, 0 }
};

/**
 * Although OpenSSl only send keylen 512 or 1024 in the call back,	Apache 
 * mod_ssl adjust the key length to the size of RSA/DSA private key used
 * for the current connection, and always use at least 1024-bit parameters.
 * We do the same here. The drawback is some weak, export 512 bit cipher
 * doesn't work any more, which is totally ok.
 */
static DH *ssl_tmp_dh_cb(SSL *ssl, int export, int keylen)
{
	EVP_PKEY *pkey;
	int type;
	int n;

	pkey = SSL_get_privatekey(ssl);
#if OPENSSL_VERSION_NUMBER < 0x10100000L
	type = pkey ? EVP_PKEY_type(pkey->type) : EVP_PKEY_NONE;
#else
	type = pkey ? EVP_PKEY_base_id(pkey) : EVP_PKEY_NONE;
#endif

	if ((type == EVP_PKEY_RSA) || (type == EVP_PKEY_DSA)) {
		keylen = EVP_PKEY_bits(pkey);
	}

	if (smbftpd_conf.debug_mode) {
		syslog(LOG_DEBUG, "Generating temp DH (%d bit)", keylen);
	}
	
	for (n = 0; n < sizeof(dhparams)/sizeof(dhparams[0]); n++) {
		if (keylen >= dhparams[n].min) {
			if (NULL == dhparams[n].dh) {
				dhparams[n].dh = make_dh(dhparams[n].prime, "2");;
			}
			return dhparams[n].dh;
		}
	}
	return NULL;
}
#endif /* WITH_SSL */

/**
 * Initial the SSL library and load cert.
 * 
 * @return 
 */
int smbftpd_ssl_init()
{
#ifdef	WITH_SSL
	const unsigned char ctx_sid[] = "smbftpd";
	
	if (ssl_ctx != NULL) {
		SSL_CTX_free(ssl_ctx);
		ssl_ctx = NULL;
	}

	if (!(smbftpd_conf.security_policy & SECURITY_POLICY_SECURE)) {
		return 0;
	}
	if ( (NULL == smbftpd_conf.ssl_cert_file) || (NULL == smbftpd_conf.ssl_cert_file)) {
		syslog(LOG_ERR, "%s (%d) Please set the SSLCertFile and SSLKeyFile",
			   __FILE__, __LINE__);
		return -1;
	}

	/*
	 * Init things so we will get meaningful error messages rather than
	 * numbers
	 */
	SSL_load_error_strings();
	SSL_library_init();

	ssl_ctx = (SSL_CTX *)SSL_CTX_new(SSLv23_method());

	SSL_CTX_set_options(ssl_ctx, SSL_OP_ALL|SSL_OP_NO_SSLv2|SSL_OP_NO_SSLv3);
	SSL_CTX_set_options(ssl_ctx, SSL_OP_NO_COMPRESSION|SSL_OP_NO_TICKET);

	SSL_CTX_set_session_id_context(ssl_ctx, ctx_sid, strlen((char *)ctx_sid));
	SSL_CTX_set_session_cache_mode(ssl_ctx, SSL_SESS_CACHE_SERVER);
	SSL_CTX_set_timeout(ssl_ctx, 60 * 60L);

	if (NULL != smbftpd_conf.ssl_ca_cert_file) {
		STACK_OF(X509_NAME) *cert_names;
		
		if (!SSL_CTX_load_verify_locations(ssl_ctx, smbftpd_conf.ssl_ca_cert_file, NULL)) {
			syslog(LOG_ERR, "%s (%d) Error loading '%s' (%s)",
				   __FILE__, __LINE__, smbftpd_conf.ssl_ca_cert_file,
				   ERR_error_string(ERR_get_error(), NULL));
			return -1;
		}

		cert_names = SSL_load_client_CA_file(smbftpd_conf.ssl_ca_cert_file);
		if (NULL == cert_names) {
			syslog(LOG_ERR, "%s (%d) Failed to load %s (%s)", __FILE__, __LINE__,
				   smbftpd_conf.ssl_ca_cert_file, ERR_error_string(ERR_get_error(), NULL));
			return -1;
		}
		SSL_CTX_set_client_CA_list(ssl_ctx, cert_names);
	}

	if (!SSL_CTX_use_certificate_chain_file(ssl_ctx, smbftpd_conf.ssl_cert_file)) {
		syslog(LOG_ERR, "%s (%d) Error loading '%s' (%s)", 
			   __FILE__, __LINE__, smbftpd_conf.ssl_cert_file,
			   ERR_error_string(ERR_get_error(), NULL));
		return -1;
	}

	if (!SSL_CTX_use_PrivateKey_file(ssl_ctx, smbftpd_conf.ssl_key_file, SSL_FILETYPE_PEM)) {
		syslog(LOG_ERR, "%s (%d) Error loading '%s' (%s)", 
			   __FILE__, __LINE__, smbftpd_conf.ssl_key_file, ERR_error_string(ERR_get_error(), NULL));
		return -1;
	}
	if (!SSL_CTX_check_private_key(ssl_ctx)) {
		syslog(LOG_ERR, "%s (%d) Error loading. Private key error. '%s'",
			   __FILE__, __LINE__, smbftpd_conf.ssl_key_file);
		return -1;
	}

	SSL_CTX_set_tmp_rsa_callback(ssl_ctx, ssl_tmp_rsa_cb);
	SSL_CTX_set_tmp_dh_callback(ssl_ctx, ssl_tmp_dh_cb);
#ifdef WITH_SSL_ECC
	SSL_CTX_set_tmp_ecdh(ssl_ctx, EC_KEY_new_by_curve_name(NID_X9_62_prime256v1));
#endif /* WITH_SSL_ECC */

	SSL_CTX_set_cipher_list(ssl_ctx, smbftpd_conf.ssl_cipher_suite);
	
	SSL_CTX_set_default_verify_paths(ssl_ctx);

	/*
	ssl_verify_flag = SSL_VERIFY_NONE;
	ssl_verify_flag = SSL_VERIFY_PEER;
	ssl_verify_flag = SSL_VERIFY_PEER | SSL_VERIFY_FAIL_IF_NO_PEER_CERT;
	*/
	SSL_CTX_set_verify(ssl_ctx, SSL_VERIFY_PEER, NULL);

#endif

	return (0);
}

void smbftpd_ssl_free(void)
{
#ifdef	WITH_SSL
	int n;

	if (ssl_ctx != NULL) {
		SSL_CTX_free(ssl_ctx);
		ssl_ctx = NULL;
	}
	if (ssl_tmp_rsa512) {
		RSA_free(ssl_tmp_rsa512);
		ssl_tmp_rsa512 = NULL;
	}
	if (ssl_tmp_rsa1024) {
		RSA_free(ssl_tmp_rsa1024);
		ssl_tmp_rsa1024 = NULL;
	}
	for (n = 0; n < sizeof(dhparams)/sizeof(dhparams[0]); n++) {
		if (dhparams[n].dh) {
			DH_free(dhparams[n].dh);
			dhparams[n].dh = NULL;
		}
	}
#endif
	return;
}
